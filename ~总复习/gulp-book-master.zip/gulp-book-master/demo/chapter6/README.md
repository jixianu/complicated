# 使用 gulp 编译 Sass - 示例代码

[gulp 入门指南](https://github.com/nimojs/gulp-book)

本目录 [使用 gulp 编译 Sass](../../chapter6.md)章节中的示例代码


## 安装依赖
打开命令行切换至此目录后，在命令行输入
```
npm install
```

将会安装此示例所需的模块

-------

若没有安装模块或安装模块失败。在命令行运行 `gulp`。则会出现如下报错：
```
module.js:338
    throw err;
          ^
Error: Cannot find module 'gulp-xxx'
```
