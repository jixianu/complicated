# 使用 gulp 构建一个项目 - 代码示例

本章示例完整代码全部保存在 [nimojs/gulp-demo](https://github.com/nimojs/gulp-demo)。